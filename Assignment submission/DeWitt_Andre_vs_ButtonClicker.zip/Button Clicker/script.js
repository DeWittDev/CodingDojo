function change(element) {
    element.innerText = "Logout"
}

function hide(element) {
    element.remove();
}