console.log("page loaded...");

var x = document.getElementById()

function over(x) {
    x.play()
}

function out(x) {
    x.pause()
}